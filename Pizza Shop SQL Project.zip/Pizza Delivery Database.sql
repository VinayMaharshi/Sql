use PizzaDB;

--To check the tables that are in the database.
Select name
from sys.tables;

CREATE TABLE [Orders] (
    row_id INT  NOT NULL ,
    order_id VARCHAR(10)  NOT NULL ,
    item_id VARCHAR(10)  UNIQUE NOT NULL ,
    quantity INT  NOT NULL ,
    cust_id INT UNIQUE NOT NULL ,
    delivery VARCHAR(5)  NOT NULL ,
    add_id INT UNIQUE NOT NULL ,
    created_at DATETIME  NOT NULL ,
    CONSTRAINT [PK_Orders] PRIMARY KEY CLUSTERED (
        [row_id] ASC
    )
)

--Creating the customer table
CREATE TABLE [Customers] (
    Cust_id INT  NOT NULL ,
    cust_firstname VARCHAR(50)  NOT NULL ,
    cust_lastname VARCHAR(50)  NOT NULL ,
    CONSTRAINT [PK_Customers] PRIMARY KEY CLUSTERED (
        [Cust_id] ASC
    )
)

--Creating the address table
CREATE TABLE [Address] (
    add_id INT  NOT NULL ,
    delivery_address1 VARCHAR(200)  NOT NULL ,
    delivery_address2 VARCHAR(200)  NULL ,
    delivery_city VARCHAR(50)  NOT NULL ,
    delivery_Zipcode VARCHAR(20)  NOT NULL ,
    CONSTRAINT [PK_Address] PRIMARY KEY CLUSTERED (
        [add_id] ASC
    )
)

--Creating the items table
CREATE TABLE [Item] (
    item_id VARCHAR(10)  UNIQUE NOT NULL ,
    sku VARCHAR(20)  NOT NULL ,
    item_name VARCHAR(50)  NOT NULL ,
    item_cat VARCHAR(50)  NOT NULL ,
    item_size VARCHAR(20)  NOT NULL ,
    item_price DECIMAL(5,2)  NOT NULL ,
    CONSTRAINT [PK_Item] PRIMARY KEY CLUSTERED (
        [item_id] ASC
    )
)


--Creating the shift rotation table.
CREATE TABLE [Rota] (
    rota_id INT  NOT NULL ,
    date DATETIME  NOT NULL ,
    shift_id VARCHAR(20)  NOT NULL ,
    staff_id VARCHAR(20)  NOT NULL ,
    CONSTRAINT [PK_Rota] PRIMARY KEY CLUSTERED (
        [rota_id] ASC
    )
)

--Creating the shift table
CREATE TABLE [Shift] (
    shift_id VARCHAR(20) UNIQUE NOT NULL ,
    day_of_week VARCHAR(10)  NOT NULL ,
    start_time TIME  NOT NULL ,
    end_time TIME  NOT NULL ,
    CONSTRAINT [PK_Shift] PRIMARY KEY CLUSTERED (
        [shift_id] ASC
    )
)

--Creating the staff table.
CREATE TABLE [Staff] (
    Staff_id VARCHAR(20) UNIQUE NOT NULL ,
    first_name VARCHAR(20)  NOT NULL ,
    last_name VARCHAR(20)  NOT NULL ,
    position VARCHAR(20)  NOT NULL ,
    hourly_rate DECIMAL(5,2)  NOT NULL ,
    CONSTRAINT [PK_Staff] PRIMARY KEY CLUSTERED (
        [Staff_id] ASC
    )
)

-- Add foreign key constraints by altering the table definition.
/*Before we add the foreign keys, we have to make sure that the non-primary key columns are
made unique.*/

ALTER TABLE Customers ADD CONSTRAINT FK_Customers_Cust_id 
FOREIGN KEY(Cust_id)
REFERENCES Orders(cust_id);

ALTER TABLE [Address] 
ADD CONSTRAINT FK_Address_add_id FOREIGN KEY(add_id)
REFERENCES Orders(add_id);

ALTER TABLE [Item] 
ADD CONSTRAINT [FK_Item_item_id] FOREIGN KEY([item_id])
REFERENCES Orders(item_id);

ALTER TABLE [Recipe] 
ADD CONSTRAINT [FK_Recipe_recipe_id] FOREIGN KEY([recipe_id])
REFERENCES Item(item_id);

ALTER TABLE [Ingredients] 
ADD CONSTRAINT [FK_Ingredients_ing_id] FOREIGN KEY([ing_id])
REFERENCES Recipe(ing_id)

ALTER TABLE [Inventory] 
ADD CONSTRAINT [FK_Inventory_item_id] FOREIGN KEY([item_id])
REFERENCES Item(item_id)

ALTER TABLE [Rota]
ADD CONSTRAINT [FK_Rota_staff_id] FOREIGN KEY([staff_id])
REFERENCES Staff(Staff_id)

ALTER TABLE [Rota] 
ADD CONSTRAINT [FK_Rota_shift_id] FOREIGN KEY([shift_id])
REFERENCES [Shift](shift_id)


