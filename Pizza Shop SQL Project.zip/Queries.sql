--Creating a new database called PizzaDb to store all the tables and data
CREATE DATABASE PizzaDB;

--Changing to PizzaDB to use the newly created database.
USE PizzaDB;

--Checking the tables that were inserted into the database
SELECT name
from sys.tables;

--Getting the total orders
--Joining the orders table, Address table and items table.
--We also calculte the total Price as the product of quantity and item price.
SELECT o.row_id,o.order_id,
i.item_id,o.quantity,
o.cust_id,a.add_id,i.sku,
i.item_name,i.item_price,
a.delivery_address1,
a.delivery_city,a.delivery_Zipcode,
(o.quantity * i.item_price) AS Total_Price
FROM Orders o
JOIN Item i ON o.item_id = i.item_id
JOIN Address a ON o.add_id = a.add_id;



--1) Getting the total orders from the orders table
SELECT COUNT(o.order_id) as Total_Orders
FROM Orders o; --There are a total of 30 orders.
--The count function is applied on Order_id as this will give the total number of orders.



--2) Getting the sum of the total sales. Which is the sum of the product of qunatity and item price.
SELECT o.item_id,
o.quantity,
i.item_name,
i.item_price,
(o.quantity * i.item_price) AS Total_Price
INTO #Total_Sales 
 --Creating a temporary table to hold the values. This will make Total_sale alias as a column.
FROM Orders o
JOIN Item i ON o.item_id = i.item_id;

--Queries the temp table to get the total sales.
SELECT SUM(Total_Price) as Total_sales
FROM #Total_Sales;
--We now get the total sales which is 1120.20/-



-- 3) Getting the Total items sold from the table. The total items sold is the sum of the quantity.
SELECT SUM(quantity) AS Total_items_Sold
FROM Orders;
--An Total of 80 items have been sold.




--4) Getting the Average Order Value. 
--To do this we can use the temp table from the above or divide the total price with the total items.
SELECT SUM(o.quantity * i.item_price) / SUM(o.quantity) AS Avg_Order_Value
FROM Orders o
JOIN Item i ON o.item_id = i.item_id;



--5) Sale by Item_Category. We can use the Over() or Group By clause.
/* As of now there is only one item_cat, so we are going to update and change the
item_cat for a few rows and set it to others for this project*/
--The update Statement
UPDATE Item
SET item_cat = 'Others'
WHERE item_id= 'ITEM955';

--Selecting sales by item_cat
SELECT i.item_cat,
SUM(o.quantity * i.item_price) AS Total_Sales
FROM Item i
JOIN Orders o ON i.item_id = o.item_id
GROUP BY i.item_cat;




--6&7) Total orders that were delivered and not delivered
--We use simple Count and where clause to achieve this
SELECT delivery, COUNT(delivery) AS Total_Count
FROM Orders
GROUP BY Delivery;




--8) Number of Hours that the staff has been working
/* From the three tables Rota, Staff and shift we get various columns. To calcualte the number
of hour each staff member has worked, we use the time diff and hour function.*/
SELECT r.rota_id,r.shift_id, r.staff_id,
s.start_time, s.end_time,
CASE
	WHEN s.end_time >= s.start_time THEN ABS(DATEDIFF(HOUR,s.end_time,s.start_time))
	ELSE ABS(DATEDIFF(HOUR,s.start_time,s.end_time) + 24)
	END AS Total_Hours,
/*Since the date is in 24 hour format, we use the ABS()*/
/*When you calculate the difference between evening 5 PM and morning 1 AM, 
it's indeed 16 hours if you treat it as a duration within the same day. However, 
you may want to consider it as spanning across two days and calculate the correct time difference.
To do this, you can use a combination of CASE statements to adjust the time
difference if the end time is earlier than the start time.*/
CONCAT(sf.first_name,' ',sf.last_name) AS Staff_Name, sf.hourly_rate
INTO #Temp_staff
FROM Rota r
JOIN Shift s ON r.shift_id = s.shift_id
JOIN Staff sf ON r.staff_id = sf.Staff_id;

--Selecting the total_hours and Emp name from the temp table.
SELECT Staff_name, Total_hours
FROM #Temp_staff;




--9) Average Wages earned by each type of Employee per hour.
--We will use staff,Shift and Rota table from above to calculate wages and group them by Positon.
SELECT r.rota_id,r.shift_id, r.staff_id,
s.start_time, s.end_time,
CASE
	WHEN s.end_time >= s.start_time THEN ABS(DATEDIFF(HOUR,s.end_time,s.start_time))
	ELSE ABS(DATEDIFF(HOUR,s.start_time,s.end_time) + 24)
	END AS Total_Hours,
CONCAT(sf.first_name,' ',sf.last_name) AS Staff_Name, sf.hourly_rate, sf.position
INTO #temp_wages
FROM Rota r
JOIN Shift s ON r.shift_id = s.shift_id
JOIN Staff sf ON r.staff_id = sf.Staff_id;

--Selecting from the temp_table
SELECT Position,
SUM(Total_hours * hourly_rate)/SUM(Total_Hours) as Average_Wages
FROM #temp_wages
GROUP BY Position;



--10) To calculate the monthly average wages the employees based on category.
-- We will use the same temp table that we already created.
SELECT Position,
CAST(SUM(Total_hours * hourly_rate*30)/20 AS DECIMAL(10,1)) AS Average_Wages
FROM #temp_wages
GROUP BY Position;

